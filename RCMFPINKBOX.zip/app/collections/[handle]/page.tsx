import Link from "next/link"
import Image from "next/image"
import { notFound } from "next/navigation"
import { getCollectionProducts } from "@/lib/shopify"
import { SHOPIFY_STORE_URL } from "@/lib/shopify"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Gift, ArrowLeft } from "lucide-react"
import type { ShopifyProduct } from "@/lib/shopify/types"

interface CollectionPageProps {
  params: Promise<{ handle: string }>
}

export default async function CollectionPage({ params }: CollectionPageProps) {
  const { handle } = await params
  
  const products = await getCollectionProducts({
    collection: handle,
    limit: 24,
    sortKey: "MANUAL",
  })

  // If no products found, could mean collection doesn't exist
  if (products.length === 0) {
    // Show empty state instead of 404 to handle case where collection exists but is empty
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 max-w-6xl mx-auto px-4 py-16">
          <Link 
            href="/" 
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Link>
          <div className="text-center py-20">
            <h1 className="font-serif text-3xl md:text-4xl text-foreground mb-4">
              {formatCollectionTitle(handle)}
            </h1>
            <p className="text-muted-foreground mb-8">
              No products available in this collection yet. Check back soon!
            </p>
            <Button asChild>
              <Link href={SHOPIFY_STORE_URL} target="_blank" rel="noopener noreferrer">
                Visit Our Store
              </Link>
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        {/* Collection Header */}
        <section className="bg-accent/30 py-12 md:py-16">
          <div className="max-w-6xl mx-auto px-4">
            <Link 
              href="/" 
              className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Link>
            <h1 className="font-serif text-3xl md:text-5xl text-foreground mb-4">
              {formatCollectionTitle(handle)}
            </h1>
            <p className="text-muted-foreground max-w-2xl">
              Curated fashion drops styled with intention. Each piece is carefully selected to help you feel polished and powerful.
            </p>
          </div>
        </section>

        {/* Products Grid */}
        <section className="py-12 md:py-16">
          <div className="max-w-6xl mx-auto px-4">
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

function ProductCard({ product }: { product: ShopifyProduct }) {
  const image = product.images.edges[0]?.node
  const price = product.priceRange.minVariantPrice
  const compareAtPrice = product.compareAtPriceRange?.minVariantPrice
  const hasDiscount = compareAtPrice && parseFloat(compareAtPrice.amount) > parseFloat(price.amount)
  
  // Link directly to the product on Shopify for checkout
  const productUrl = `${SHOPIFY_STORE_URL}/products/${product.handle}`

  return (
    <Card className="border-border overflow-hidden group">
      <Link href={productUrl} target="_blank" rel="noopener noreferrer">
        <div className="aspect-square relative bg-muted overflow-hidden">
          {image ? (
            <Image
              src={image.url}
              alt={image.altText || product.title}
              fill
              className="object-cover group-hover:scale-105 transition-transform duration-300"
              sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center">
              <Gift className="h-12 w-12 text-muted-foreground/50" />
            </div>
          )}
          {!product.availableForSale && (
            <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
              <span className="text-sm font-medium text-muted-foreground">Sold Out</span>
            </div>
          )}
        </div>
        <CardContent className="p-4">
          <h3 className="font-medium text-foreground mb-2 line-clamp-2 group-hover:text-primary transition-colors">
            {product.title}
          </h3>
          <div className="flex items-center gap-2">
            <span className="text-foreground font-medium">
              {formatPrice(price.amount, price.currencyCode)}
            </span>
            {hasDiscount && (
              <span className="text-muted-foreground line-through text-sm">
                {formatPrice(compareAtPrice.amount, compareAtPrice.currencyCode)}
              </span>
            )}
          </div>
          {product.availableForSale && (
            <Button className="w-full mt-4 bg-primary hover:bg-primary/90 text-primary-foreground">
              Shop Now
            </Button>
          )}
        </CardContent>
      </Link>
    </Card>
  )
}

function Header() {
  return (
    <header className="border-b border-border bg-card/80 backdrop-blur-sm sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <Gift className="h-6 w-6 text-primary" />
          <span className="font-serif text-xl tracking-wide text-foreground">
            Recycle Me Fancy
          </span>
        </Link>
        <nav className="hidden md:flex items-center gap-6">
          <Link 
            href="/collections/pink-box-drops" 
            className="text-muted-foreground hover:text-foreground transition-colors text-sm"
          >
            Shop
          </Link>
          <Link 
            href="/#about" 
            className="text-muted-foreground hover:text-foreground transition-colors text-sm"
          >
            About
          </Link>
          <Link 
            href="/#themes" 
            className="text-muted-foreground hover:text-foreground transition-colors text-sm"
          >
            Themes
          </Link>
        </nav>
        <Button asChild size="sm" className="bg-primary hover:bg-primary/90 text-primary-foreground">
          <Link href="/collections/pink-box-drops">
            Shop Now
          </Link>
        </Button>
      </div>
    </header>
  )
}

function Footer() {
  return (
    <footer className="border-t border-border bg-card py-12">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <Link href="/" className="flex items-center gap-2">
            <Gift className="h-5 w-5 text-primary" />
            <span className="font-serif text-lg text-foreground">Recycle Me Fancy</span>
          </Link>
          <nav className="flex items-center gap-6">
            <Link 
              href="/collections/pink-box-drops" 
              className="text-muted-foreground hover:text-foreground transition-colors text-sm"
            >
              Shop
            </Link>
            <Link 
              href="/#about" 
              className="text-muted-foreground hover:text-foreground transition-colors text-sm"
            >
              About
            </Link>
            <Link 
              href="/#themes" 
              className="text-muted-foreground hover:text-foreground transition-colors text-sm"
            >
              Themes
            </Link>
          </nav>
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} Recycle Me Fancy. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}

function formatCollectionTitle(handle: string): string {
  return handle
    .split("-")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")
}

function formatPrice(amount: string, currencyCode: string): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: currencyCode,
  }).format(parseFloat(amount))
}
